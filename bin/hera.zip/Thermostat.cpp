#include <Wire.h>
#include "E2PROM.h"
#include "Thermostat.h"
#include "Log.h"

const char* Thermostat::deviceClass = "js.hera.dev.Thermostat";

Thermostat::Thermostat(const char* deviceName, const char* sensorName, byte port, OutMode outMode, byte eepromAddr):
  Device(deviceClass, deviceName),
  sensorName(sensorName),
  port(port, outMode),
  eepromAddr(eepromAddr)
{
}

void Thermostat::setup() {
  Log::trace("Thermostat::setup");

  port.setup();
  state = 0;

  Log::debug("Read device state from EEPROM: ", deviceName);
  E2PROM::get(eepromAddr, setpoint);
  if (setpoint < 16 || setpoint > 28) {
    setpoint = 20;
  }
  Log::debug("setpoint: ", String(setpoint));
  
  // set initial temperature to high value to prevent activating port in transient state
  // at first temperature read, be it localy or from net temperature sensor, temperature is updated to environment value
  temperature = 28.0;
}

void Thermostat::loop()
{
  // update port state on every loop iteration in order to have quick response for setpoint changes
  updatePort();
}

String Thermostat::invoke(const String& action, const String& parameter)
{
  Log::trace("Thermostat::invoke");

  if (action == "setSetpoint") {
    setpoint = parameter.toFloat();
    Log::debug("Write device state to EEPROM: ", deviceName);
    E2PROM::put(eepromAddr, setpoint);
  }
  else if (action == "getSetpoint") {
    return String(setpoint);
  }
  else if (action == "getTemperature") {
    return String(temperature);
  }
  else if (action == "getState") {
    return String(port.getState() ? "true" : "false");
  }

  return "";
}

void Thermostat::updatePort() {
  byte currentState = setpoint > temperature ? 1 : 0;
  if (state != currentState) {
    Log::debug("port.setState: " + String(currentState));
    port.setState(currentState);
    MessagePublisher::publishDeviceState(deviceName, port.getState());
    state = currentState;
  }
}

