#ifndef __HERA_NET_TEMPERATURE_SENSOR
#define __HERA_NET_TEMPERATURE_SENSOR

#include "Device.h"
#include "InPort.h"

class TemperatureSensor: public Device {
  public:
    TemperatureSensor(const char* deviceName, byte sensorAddress, byte period, float threshold);
    TemperatureSensor(const char* deviceName, byte sensorAddress, byte period, float threshold, float offset);

    void setup();
    void loop();
    String invoke(const String& action, const String& parameter = "");

  private:
    // TMP102 device address
    byte sensorAddress;

    // temperature sensor reading period
    long period;

    // signed offset added to measured value for ambient compensation
    float offset;

    // hysteresis timeout timestamp
    long timestamp;

    float currentTemperature;

    float threshold;

  private:
    static const char* deviceClass;
};

#endif

