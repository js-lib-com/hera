#include <Wire.h>
#include <ESP8266mDNS.h>

#include "TemperatureSensor.h"
#include "MessagePublisher.h"
#include "Log.h"

const char* TemperatureSensor::deviceClass = "js.hera.dev.TemperatureSensor";

TemperatureSensor::TemperatureSensor(const char* deviceName, byte _sensorAddress, byte _period, float _threshold):
  Device(deviceClass, deviceName),
  sensorAddress(_sensorAddress),
  period(1000 * _period),
  threshold(_threshold),
  offset(0),
  currentTemperature(0)
{
}

TemperatureSensor::TemperatureSensor(const char* deviceName, byte _sensorAddress, byte _period, float _threshold, float _offset):
  Device(deviceClass, deviceName),
  sensorAddress(_sensorAddress),
  period(1000 * _period),
  threshold(_threshold),
  offset(_offset),
  currentTemperature(0)
{
}

void TemperatureSensor::setup() {
  Log::trace("TemperatureSensor::setup");
  Wire.begin();
  timestamp = 0;
}

void TemperatureSensor::loop() {
  // do not read temperature sensor at every loop iteration to filter out quick, not stable temperature changes
  if (millis() - timestamp < period) {
    return;
  }

  if (Wire.requestFrom(sensorAddress, 2) != 2) {
    Log::error("No data from sensor.");
    return;
  }

  byte MSB = Wire.read();
  byte LSB = Wire.read();
  float temperature = (((MSB << 8) | LSB) >> 4) * 0.0625;
  Log::debug("temperature: " + String(temperature));
  temperature += offset;
  Log::debug("compensated temperature: " + String(temperature));

  timestamp = millis();

  if (fabs(currentTemperature - temperature) >= threshold) {
    currentTemperature = temperature;
    Log::debug("threshold detected: " + String(currentTemperature));
    MessagePublisher::publishDeviceState(deviceName, currentTemperature);
  }
}

String TemperatureSensor::invoke(const String& action, const String& parameter) {
  Log::trace("TemperatureSensor::invoke");

  if (action == "getValue") {
    return String(currentTemperature);
  }
}

