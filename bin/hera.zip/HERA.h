#ifndef __HERA_FACADE
#define __HERA_FACADE

#include <IPAddress.h>

#include "Log.h"
#include "BinaryLight.h"
#include "LightDimmer.h"
#include "Actuator.h"
#include "ContactSwitch.h"
#include "PushButton.h"
#include "RadioSwitch.h"
#include "DHTSensor.h"
#include "ColorLED.h"
#include "LightSensor.h"
#include "TemperatureSensor.h"

extern const char* HOST_NAME;
extern const char* WIFI_SSID;
extern const char* WIFI_PASSWORD;

class HERA {
  public:
    void setup();
    void setup(Device** devices, byte devicesCount);
    void loop();

  public:
    void onSubscribe();
    void onInvoke();

  private:
    void advertise(IPAddress address, int port);
    void sendVoid();
    void sendResult(const String& result);
    void sendServerError();

  private:
    Device** devices;
    byte devicesCount;
};

extern HERA hera;

#endif


